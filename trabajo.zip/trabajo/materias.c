#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "materias.h"
#include "calificaciones_matricula.h"

void volcado_entrada_mat(materia ** v_materias, int * n_materias)
{
	FILE *fichero;
	int len;
    char linea[60]; //guardamos una linea del fichero antes de tratarla (130 es el tama�o maximo que puede alcanzar una linea)
    char *token=NULL; //Nos permitir� dividir la cadena en segmentos

    *v_materias=NULL;
    *n_materias=0;
    
    fichero = fopen("Materias.txt","r");
     
     if (fichero == NULL)
	 {
	 	puts("Error al abrir el fichero:se encuentra vacio o no existe");
	 }
	 else
	 {
	 	do{
	 		if ( ((fgets(linea,60,fichero) ) != (NULL) ))
			 {     
            
                *v_materias=realloc((materia *)(*v_materias),((*n_materias)+1)*sizeof(materia));

				len=strlen(linea);
                linea[len - 1] = '\0'; // Eliminamos el retorno de la cadena del fichero de texto
              
               //partimos la cadena en segmentos para poder almacenarla
			    token=strtok(linea,"-");
			    if(token == NULL) break;
                strcpy((*v_materias)[*n_materias].id_materia,token);
				
				token=strtok(NULL,"-");
				if (token==NULL) break;
                strcpy((*v_materias)[*n_materias].nombre_materia,token);
				
				token=strtok(NULL,"-");
				if (token==NULL) break;
            	strcpy((*v_materias)[*n_materias].abrev_materia,token);
		    (*n_materias)++;
            
        }
		 }while (!(feof(fichero))); //Realizamos la conversion mientras nos queden lineas en el fichero
		 fclose (fichero);
	 }
}

void dar_alta_mat(materia* v_materias,int *n_materias)
{
	bool flag = false;
	int i;
	for (i = 0; i < *n_materias;i++)
	{
		if(strcmp(v_materias[i].id_materia,"000000") == 0) //Si ha ocurrido un borrado, machacamos sus campos para a�adir al nuevo alumno
		{
			if(i == 0) //Si el alumno previo era el primero, es un caso especial
			{
			strcpy(v_materias[i].id_materia,"000001");	
			}
			
			else  //Si no es el primero, realizamos el tratamiendo general a la id
			{
				int id = atoi(v_materias[i-1].id_materia);
				id++;
				sprintf(v_materias[i].id_materia,"%d",id);
			}
			
			char nombre_nuevo [51];
					do
					{	
						printf("Introduzca el nuevo nombre, maximo 50 caracteres (pulse intro para finalizar):");
						scanf("%s",nombre_nuevo);
						if (strlen(nombre_nuevo) > 50) printf("El nombre no es valido");
						else strcpy(v_materias[i].nombre_materia,nombre_nuevo);
					} while (strlen(nombre_nuevo) > 50);
					
			char abrev_nuevo [4];
					do
					{
						printf("Introduzca el nuevo nombre, maximo 3 caracteres (pulse intro para finalizar):");
						scanf("%s",abrev_nuevo);
						if (strlen(abrev_nuevo) > 3) printf("La direccion no es valida");
						else strcpy(v_materias[i].abrev_materia,abrev_nuevo);
					} while (strlen(abrev_nuevo) > 3);	
					i = *n_materias; //Si hemos insertado en una posicion borrada (intermedia) no necesitamos recorrer el bucle
					flag = true;
		
	if( flag == false) //Si no hemos insertado en una posicion ya existente, debemos a�adir una nueva posicion
	{
		v_materias=realloc((materia *)(v_materias),((*n_materias)+1)*sizeof(materia));
		int i = *n_materias;
		*n_materias+=1;
		int id = atoi(v_materias[i].id_materia);
		id++;
		sprintf(v_materias[i+1].id_materia,"%d",id);
		//Pasamos a a�adir los valores restantes del nuevo alumno
		char nombre_nuevo [51];
					do
					{	
						printf("Introduzca el nuevo nombre, maximo 50 caracteres (pulse intro para finalizar):");
						scanf("%s",nombre_nuevo);
						if (strlen(nombre_nuevo) > 50) printf("El nombre no es valido");
						else strcpy(v_materias[i].nombre_materia,nombre_nuevo);
					} while (strlen(nombre_nuevo) > 50);
					
			char abrev_nuevo [4];
					do
					{
						printf("Introduzca el nuevo nombre, maximo 3 caracteres (pulse intro para finalizar):");
						scanf("%s",abrev_nuevo);
						if (strlen(abrev_nuevo) > 3) printf("La direccion no es valida");
						else strcpy(v_materias[i].abrev_materia,abrev_nuevo);
					} while (strlen(abrev_nuevo) > 3);	

					
			}
		}
	}
}

void dar_baja_mat(materia* v_materias,int n_materias,char id [])
{
	bool flag_borrado = false;
	int i;
	for (i = 0; i < n_materias;i++)
	{
		if (strcmp(id,v_materias[i].id_materia) == 0)
		{
			
			strcpy(v_materias[i].id_materia,"000000");
			flag_borrado = true;
			i = n_materias;	//si hemos encontrado la materia, salimos del bucle		
		}
	}
	if (flag_borrado == true)
	{
		eliminar_matricula_materia(&matri,id,&num_lin_Matriculas.lon);
		eliminar_calificaciones_materia(&cali,id,&num_lin_Calificaciones.lon);
		//borrar horarios con la id dada
	}
}

void modif_mat(materia* v_materias,int n_materias,char id [])
{
		int mod,i;
	for (i = 0; i < n_materias;i++)
	{
		if (strcmp(id,v_materias[i].id_materia) == 0)
		{
			printf("�Que desea modificar?\n 1.Nombre alumno\n 2.direccion\n 3.localidad\n4.curso\n 5.grupo ");
			scanf("%d", &mod);
			switch(mod)
			{
				case (1): ;//se pedira por pantalla y se modificar� si es valido.
				char nombre_nuevo [51];
					do
					{	
						printf("Introduzca el nuevo nombre, maximo 50 caracteres (pulse intro para finalizar):");
						scanf("%s",nombre_nuevo);
						if (strlen(nombre_nuevo) > 50) printf("El nombre no es valido");
						else strcpy(v_materias[i].nombre_materia,nombre_nuevo);
					} while (strlen(nombre_nuevo) > 50);
					
				case(2): ;
				char abrev_nuevo [4];
					do
					{
						printf("Introduzca la abreviatura, maximo 3 caracteres (pulse intro para finalizar):");
						scanf("%s",abrev_nuevo);
						if (strlen(abrev_nuevo) > 4) printf("La abreviatura no es valida");
						else strcpy(v_materias[i].abrev_materia,abrev_nuevo);
					} while (strlen(abrev_nuevo) > 4);
			}	
		}
	}
}

void listar_mat(materia* v_materias,int n_materias)
{
	int i;
	if (n_materias > 0)
	{
		for (i = 0; i < n_materias;i++)
		{
			printf("%s %s %s \n",v_materias[i].id_materia,v_materias[i].nombre_materia,v_materias[i].abrev_materia);
		}
	}
}

void volcar_fichero_mat(materia* v_materias,size_t tam)
{
	FILE *f;
	int i;
	
	//Escribe en el fichero toda la lista de usuarios
	f = fopen ("Materias.txt", "w+");
	
	i = 0;
	
	if (f == NULL) puts ("\tNo se ha podido modificar el fichero");
	else{
		while (i < tam-1){
			fprintf(f, "%s-%s-%s\n", v_materias[i].id_materia, v_materias[i].nombre_materia, v_materias[i].abrev_materia);
			
			i++;
		}
	}
	fprintf (f, "%s-%s-%s\n", v_materias[i].id_materia, v_materias[i].nombre_materia, v_materias[i].abrev_materia);
	
	puts ("\tSe han volcado los usuarios correctamente.");
	
	fclose (f);
	
	system("pause");
}

