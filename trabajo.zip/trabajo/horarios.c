//Implementaci�n m�dulo Horarios

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Horarios.h"


//Cabecera: void cargarHorarios(tipo_Horario **, int *);
//Precondicion: Como par�metros un vector tipo horario y un entero por referencia.
//Postcondicion: Vuelca la informacion del fichero Horarios.txt a estructuras del programa
void cargarHorarios(tipo_Horario **vHorarios, int *n){
	
	FILE *fichero;
	int len;
    char linea[57];             // Guardar cada linea que leamos del fichero (57 como maximo)
    char *token=NULL;
    
    *vHorarios=NULL;		//Inicializamos a 0 el vector de tipo horario
    *n=0;					//Inicializamos a 0 el contador de horarios
    
    //Abrimos el fichero y comprobamos que lo haga correctamente.
	fichero = fopen ("Horarios.txt", "r");		
	if (fichero==NULL) {
		printf("ERROR al abrir el fichero...\n");
	 	exit(2);
	}	
	
	do{
			if ( (fgets(linea,44,fichero) ) != NULL) 
			{
                *vHorarios=realloc((tipo_Horario *)(*vHorarios),((*n)+1)*sizeof(tipo_Horario));		//Reservamos memoria dinamica por cada linea (horario) que lea

                token=strtok(linea,"-");
                if (token==NULL) break;
                

                strcpy((*vHorarios)[*n].id_prof,token);
                token=strtok(NULL,"-");
                if (token==NULL) break;
                
                (*vHorarios)[*n].dia_clase=atoi(token);
                token=strtok(NULL,"-");
                if (token==NULL) break;
                
               
                (*vHorarios)[*n].hora_clase=atoi(token);
                token=strtok(NULL,"-");
                if (token==NULL) break;
                
                
                strcpy((*vHorarios)[*n].id_materia,token);
                token=strtok(NULL,"-");
                if (token==NULL) break;
                
               
                strcpy((*vHorarios)[*n].grupo,token);
                

                (*n)++;

            }

        }while(!feof(fichero));
 
    fclose(fichero);

}


//Cabecera: void volcarHorarios(tipo_Horario *vHorarios, size_t tam);
//Precondicion: Recibe un vector de horarios igual o modificado y el numero de horarios
//Postcondicion: Vuelca en el fichero Horarios.txt las nuevas modificaciones en los horarios
void volcarHorarios(tipo_Horario *vH, size_t tam) {
	FILE *f;
	int i;
	
	//Escribe en el fichero Horarios.txt toda la lista de Horarios
	f = fopen ("Horarios.txt", "w+");
	
	i = 0;
	
	if (f == NULL) puts ("\tNo se ha podido modificar el fichero");
	else {
		while (i < tam-1){
			
			fprintf(f, "%s-%d-%d-%s-%s", vH[i].id_prof, vH[i].dia_clase, vH[i].hora_clase, vH[i].id_materia, vH[i].grupo);
			i++;
		}
	}
	fprintf(f, "%s-%d-%d-%s-%s\n", vH[i].id_prof, vH[i].dia_clase, vH[i].hora_clase, vH[i].id_materia, vH[i].grupo);
	
	puts ("\tSe han guardado los horarios correctamente");
	
	system("pause");
}



//Cabecera: void listarHorarios (tipo_Horario *, int);
//Precondicion: Vector de tipo horario declarado y entero
//Postcondicion: Muestra por pantalla al usuario la lista de horarios
void listarHorarios (tipo_Horario *vHorarios, int n) {
	int i;

    if(n == 0)
        printf("\tNo tienes horarios registrados \n");
    else
        for(i=0;i<n;i++){
            printf("%d) %s-%d-%d-%s-%s", i+1, vHorarios[i].id_prof, vHorarios[i].dia_clase, vHorarios[i].hora_clase, vHorarios[i].id_materia, vHorarios[i].grupo);
        }
}


//void annadirHoras(tipo_Horario **vHorarios, int *nHorarios)
//Precondicion: Se reciben por referencia un vector de tipo Horario y el numero de estos
//Postcondicion: A�ade horarios al profesor seleccionado por el id.
void annadirHoras(tipo_Horario **vHorarios, int *nHorarios){
	int n,i, aux1, aux2 = 0;
    int h = -1;
    int repetido = 0;

    *vHorarios=realloc((tipo_Horario *)(*vHorarios),((*nHorarios)+1)*sizeof(tipo_Horario));

	do {
		repetido=0;
		puts("\tIntroduzca el id del profesor (3 cifras maximo):");
    	fflush(stdin);
    	printf("\t");
   		scanf("%3s",(*vHorarios)[*nHorarios].id_prof);

	for(i=0; i<*nHorarios; i++){

            if(strcmp((*vHorarios)[i].id_prof,(*vHorarios)[*nHorarios].id_prof )==0){

                h=i;
                if (i != *nHorarios) { repetido = 1;}
				break;
            }
        }

    	if(repetido == 1){

            puts("\tERROR: El  id de horario seleccionado ya esta registrado introduzca otro \n "); 
		   
		}
            
    } while ( repetido == 1) ;
    
    do {
    	puts("\tIntroduzca el dia del profesor (1-5):");
    	fflush(stdin);
    	printf("\t");
    	fflush(stdin);
    	scanf("%d", &aux1);
    	(*vHorarios)[*nHorarios].dia_clase = aux1;
		
	}while (aux1<1 || aux1>5);
    

    do {
    	puts("\tIntroduzca la hora de clase del profesor (1-6):");
    	fflush(stdin);
    	printf("\t");
    	fflush(stdin);
    	scanf("%d", &aux2);
    	(*vHorarios)[*nHorarios].hora_clase = aux2;
		
	}while (aux2<1 || aux2>6);
    
    puts("\tIntroduzca el id de la materia que imparte el profesor (5 caracteres maximo):");
    fflush(stdin);
    printf("\t");
    fgets ((*vHorarios)[*nHorarios].id_materia, 6, stdin);
    cambiolinea ((*vHorarios)[*nHorarios].id_materia);

    puts("\tIntroduzca el grupo al que imparte el profesor (10 caracteres maximo):");
    fflush(stdin);
    printf("\t");
    fgets ((*vHorarios)[*nHorarios].grupo, 11, stdin);
    cambiolinea ((*vHorarios)[*nHorarios].grupo);

    (*nHorarios)++;
}


//cabecera:void eliminarHoras(tipo_Horario **vHorarios,int *nHorarios);
//precondicion: recibe el vector horarios (vHorarios) y el numero total de horarios (nHorarios).
//postcondicion: elimina el horario indicado.
void eliminarHoras(tipo_Horario **vHorarios,int *nHorarios){

    int i;
    int h = 0;
    char resp=' ';
    char id[4];

    puts("______________________________________________________________\n");
    puts("\tELIMINAR HORARIO PROFESOR");
    puts("______________________________________________________________\n");

    printf("\tIntroduzca el id del profesor a eliminar: ");
    printf("\t");
    scanf("%3s",id);

    for(i=0;i<(*nHorarios);i++){

        if(strcmp((*vHorarios)[i].id_prof, id)==0){

            h=i;

        }

    }

    while(resp!='s' && resp!='n'){

        printf("\tSe va a eliminar el siguiente usuario: %s-%d-%d-%s-%s\n", (*vHorarios)[h].id_prof, (*vHorarios)[h].dia_clase, (*vHorarios)[h].hora_clase, (*vHorarios)[h].id_materia, (*vHorarios)[h].grupo);
        printf("\tEstas seguro de eliminar el horario? (s/n)\n");
        fflush(stdin);
        printf("\t");
        scanf("%c",&resp);

    }

    if(resp=='s'){

        for(i=h; i+1<(*nHorarios); i++){

            strcpy((*vHorarios)[i].id_prof,(*vHorarios)[i+1].id_prof);
            (*vHorarios)[i].dia_clase = (*vHorarios)[i+1].dia_clase;
            (*vHorarios)[i].hora_clase = (*vHorarios)[i+1].hora_clase;
            strcpy((*vHorarios)[i].id_materia,(*vHorarios)[i+1].id_materia);
            strcpy((*vHorarios)[i].grupo,(*vHorarios)[i+1].grupo);

        }

        (*nHorarios)--;

        *vHorarios=realloc((tipo_Horario *)(*vHorarios),(*nHorarios)*sizeof(tipo_Horario));

    }else{

        printf("\tSe ha cancelado la eliminacion del horario\n");

    }

}

//Cabecera: void modificarHoras(tipo_Horario **, int)
//Precondicion: Recibe por referencia un vector tipo horario y un entero que dice el numero de horarios registrados
//Postcondicion: Modifica el horario de un profesor seleccionado por su id
void modificarHoras(tipo_Horario **vHorarios, int nHorarios){
	int i;
    int h=-1;
    char resp=' ';
    char id_prof[4];

    int nModHorario=0;

    tipo_Horario *modHorario;

    modHorario=malloc(sizeof(tipo_Horario));
    
    puts("______________________________________________________________\n");
    puts("\tMODIFICAR USUARIO");
    puts("______________________________________________________________\n");

    while(h == -1){

        printf("\tIntroduzca el id del prof que desea modificar: ");
        printf("\t");
        scanf("%3s",id_prof);
        printf("\n");

        for(i=0;i<nHorarios;i++){

            if(strcmp((*vHorarios)[i].id_prof,id_prof)==0){

                h=i;
            }
        }

        if(h == -1){

            puts("\tERROR: El Profesor seleccionado no esta registrado");

        }else{

            printf("\tInformacion del horari seleccionado: %s-%d-%d-%s-%s\n\n",(*vHorarios)[h].id_prof,(*vHorarios)[h].dia_clase,(*vHorarios)[h].hora_clase,(*vHorarios)[h].id_materia,(*vHorarios)[h].grupo);
			puts("______________________________________________________________\n");
            printf("\t\tIntroduzca la nueva informaci�n del horari respetando el formato establecido (ID_PROF-DIA_CLASE-HORA_CLASE-ID_MATERIA-GRUPO)\n\n");
			puts("______________________________________________________________\n");
            annadirHoras(&modHorario,&nModHorario); 

            while(resp!='s' && resp!='n'){

                printf("\t?Desea confirmar la modificacion del horario? (s/n)\n");
                fflush(stdin);
                printf("\t");
                scanf("%c",&resp);

            }

            if(resp=='s'){

                (*vHorarios)[h]=modHorario[0];

            }else{

                printf("\tSe ha cancelado la modificacion del usuario\n");

            }

        }

    }
}


//Cabecera: void listarUsuarios()
//Postcondicion: Lista los usuarios

void cambiolinea (char * nombre){
	if ((strlen(nombre) > 0) && (nombre[strlen(nombre) - 1] == '\n'))
    {
        nombre[strlen(nombre) - 1] = '\0';
    }
}

