#ifndef MENUS_H_
#define MUNUS_H

void inicio_cuaderno();
void menu_profesores(char*);
void menu_administrador();
void menu_usuaruios();
void menu_alumnos();
void menu_materias();
void menu_horarios();
#endif


