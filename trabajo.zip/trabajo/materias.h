
#ifndef MATERIAS_H_
#define MATERIAS_H_

//Estructura dedicada a almacenar el conjunto de materias existentes en nuestro sistema de ficheros
typedef struct
{
	char  id_materia [5];
	char nombre_materia[51];
	char abrev_materia [4];
}materia;


materia * v_materias; //Puntero que se�ala el comienzo de un vector dinamico del tipo alumno
int n_materias; //Numero de materias impartidas (Encontradas en el fichero Materias.txt

//Postcondici�n:Crea un conjunto de estructuras alumno a partir del fichero
void volcado_entrada_mat(materia **, int*);

//Postcondici�n: A�ade la materia con los valores recibidos de la entrada estandar
void dar_alta_mat(materia*,int*);

//Precondici�n: Recibe la Id de la materia a borrar
//Postcondici�n: Elimina los datos correspondientes a dicha materia
void dar_baja_mat(materia*, int , char []);

//Precondici�n: Recibe la Id de la materia a modificar
//Postcondici�n: Modifica los datos correspondientes a dicha materia
void modif_mat(materia*, int , char[]);

//Postcondicion: Muestra los nombres completos de los alumnos dados de alta
void listar_mat(materia*, int);

//Postcondici�n: Sobreescribe el fichero con los datos correspondientes al as estruccturas del programa
void volcar_fichero_mat(materia*,size_t);

#endif

