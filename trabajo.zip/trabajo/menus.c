#include <stdio.h>
#include <stdlib.h>
#include "calificaciones_matricula.h"
#include "Horarios.h"
#include "Usuarios.h"
#include "alumnos.h"
#include "materias.h"

void inicio_sesion(tipo_Usuario *, int);
void obtener_datos(char*,char*);
int comparar_cad(char*,char*,int);
void menu_profesores(int, tipo_Horario *, int);
void menu_administrador();
void menu_usuarios();
void menu_alumnos();
void menu_alumno_individual(alumno *,int);
void menu_materias();
void menu_horarios();
void menu_profesores_grupo(char [], char []);
void menu_alumnos_grupo(char [], char [], alumno *, int);
void menu_alumnos_grupo_individual(char [],char [], alumno *, int);
void Calificaciones_alumno(char [],char []);

//Cabezera: void inicio_cuaderno()
//Precondici�n: Ninguna
//Postcondici�n: Se encarga de iniciar el programa y de llamar a las funione necesarias para cargar los datos de los ficheros en las estructuras
void inicio_cuaderno(){
    int x,y;
    volcado_entrada_alum(&v_alumnos,&n_alumnos);
    volcado_entrada_mat(&v_materias,&n_materias);
    introducir_Matriculas(&matri,&num_lin_Matriculas.lon);
    introducir_Calificaciones(&cali,&num_lin_Calificaciones.lon);
    cargarHorarios(&vHorarios,&nHorarios);
    cargarUsuarios(&vUsuarios,&nUsuarios);
    printf("Hola, este es el cuaderno del profesor. \n");
    do{
        while(y<1 || y>2){
            printf("Pulse 1 para iniciar sesion en el pograma. \n");
            printf("Pulse 2 para salir del pograma. \n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: inicio_sesion(vUsuarios,nUsuarios);break;
            case 2: x=1;
                    volcado_fichero_alum(v_alumnos,n_alumnos);
                    volcar_fichero_mat(v_materias,n_materias);
                    volcar_Matriculas(matri,num_lin_Matriculas.lon);  
					volcar_Calificaciones(cali,num_lin_Calificaciones.lon);
					volcarUsuarios(vUsuarios,nUsuarios);
					volcarHorarios(vHorarios,nHorarios);
                    printf("Adios, gracias por usar el programa. \n");break;
        }
    }while(x==0);
}

//Cabezera void inicio_secion(tipo_Usuario *vUsuarios, int nUsuarios)
//Precondici�n: Tener ya almacenados los datos de los ficheros dentro de las estructuras
//Precondici�n: Iniciar sesi�n dentro de un perfil de Usuario
void inicio_sesion(tipo_Usuario *vUsuarios, int nUsuarios){
    int i,j,z;
    i=0;
    j=0;
    char nom_usuario[7],contra[10];
    char c;
    obtener_datos(nom_usuario,contra);
    do{
    	if(comparar(nom_usuario,vUsuarios[j].usuario,5)==0 && comparar(contra,vUsuarios[j].contrasenna,8)==0){
    		c = vUsuarios[j].perfil[0];
    		z = j;
		}
		j++;
    }while(j<nUsuarios);
    if(c == 'p'){
    	menu_profesores(z,vHorarios,nHorarios);
	}
	if(c == 'a'){
		menu_administrador();
	}
}

//Cabezera:void obtener_datos(char* nom,char* con)
//Precondici�n: Tener creadas las dos variables que se le pasan como par�metros a la funcici�n
//Postcondici�n: Permite introducir por teclado el nombre de usuario y la contrase�a
void obtener_datos(char* nom,char* con){
    printf("Introduce el nombre de usuario.\n");
    printf("Ten en cuenta que el nombre de usuario son 5 caracteres.\n");
    fgets(nom,7,stdin);
    printf("Introduce la constrase�a.\n");
    printf("Ten en cuenta que la contrase�a son 8 caracteres.\n");
    fgets(con,10,stdin);
}

//Cabezera: int comparar_nom(char* nom1,char* nom2,int n)
//Precondici�n: Tener los valores de las dos cadenas no vacios
//Postcondici�n: Comparar si las dos cadenas son iguales
int comparar_cad(char* nom1,char* nom2,int n){
int i,j;
j=0;
for(i=0;i<n;i++){
    if(nom1[i]!=nom2[i]){
        j=1;
    }
}
return j;
}

//Cabezera: void menu_profesores(int idprof, tipo_Horario *vHorarios, int nHorarios)
//Precondici�n: Tener los datos necesarios almacenados en las estructuras y tener un id de profesor
//Postcondici�n: Te deja elegir las funciones que puede realizar un usuario profesor
void menu_profesores(int idprof, tipo_Horario *vHorarios, int nHorarios){
    int x,y,z;
    char grup[11],group2[11],materia[5];
    z=0;
    printf("Hola, estas dentro del perfil del profesor.\n");
	do{
		    printf("Seleccione un grupo de la lisa .\n");
    	do{
			if(comparar(idprof,(vHorarios)[x].id_prof,3) == 0){
				printf("%s-%s . \n", (vHorarios)[x].grupo, (vHorarios)[x].id_materia);
			}
			x++;
    	}while(x<nHorarios);
    	printf("Elige uno de los grupos indicados. \n");
    	printf("Para ello introduzca el grupo exactamente igual escrito que los de la lista. \n");
    	fgets(grup,11,stdin);
    	do{
    		if(comparar(grup,vHorarios[y].grupo,10) == 0){
    			if(comparar(idprof,(vHorarios)[y].id_prof,3) == 0){
    				copiar_cad(group2,vHorarios[y].grupo,10);
    				copiar_cad(materia,vHorarios[y].id_materia,4);
    				y=nHorarios;
				}
			}
		}while(y<nHorarios);
		if(group2 != NULL){
			menu_profesores_grupo(group2,materia);
		}
		else{
			printf("El grupo introducido no existe o no es del profesor. \n");
		}
		printf("Si desea salir pulse 1.\n");
		scanf("%i",&z);
	}while(z!=1);
}

//Cabezera: void menu_profesores_grupo(char [],char materia[])
//Precondici�n: La variable group2 tiene que tener un valor no nulo
//Postcondici�n: Meno para las opciones de lo grupos
void menu_profesores_grupo(char group[], char materia[]){
	int x,y;
	x=0;
	do{
		while(y!=1 || y!=2 || y!=3){
			printf("Elige una de las siguientes opciones. \n");
			printf("1- Listar alumnos. \n");
			printf("2- Cambiar grupo. \n");
			scanf("%i",&y);
		}
		switch(y){
			case 1: menu_alumnos_grupo(group,materia,v_alumnos, n_alumnos);
			case 2: x=1;break;
		}
	}while(x==0);
}

//Cabezera: void menu_alumnos_grupo(char group[],char materia[], alumno *v_alumnos, int n_alumnos)
//Precondici�n: Que la variable group sea no vacia
//Postcondici�n: Pone una lista de donde ahi que seleccionar un alumno
void menu_alumnos_grupo(char group[], char materia[], alumno *v_alumnos, int n_alumnos){
	int x,y,z;
	char id[7];
	z=0;
	printf("Los alumnos que se encuentran en este grupo son: \n");
	do{
		if(comparar(group,v_alumnos[x].grupo),10){
			printf("%s-%s.\n",v_alumnos[x].id_alum,v_alumnos[x].nombre_alum);
		}
		x++;
	}while(x<n_alumnos);
	do{
		printf("Introduce el identificador del alumno: ");
		fgets(id,7,stdin);
		do{
			if(comparar(id,v_alumnos[x].id_alum,6) == 0){
				menu_alumnos_grupo_individual(id,materia,v_alumnos,n_alumnos);
				z=1;
			}
		}while(y<n_alumnos);
		printf("Desea probar otra vez \n");
		printf("Pulse 1 para salir si lo desea y cualquier otro numeri para introducir el id de nuevo.\n");
		scanf("%i",&z);
	}while(z != 1);
}

//Cabezera: void menu_alumnos_grupo_individual(char id[],char materia[],  alumno *v_alumnos, int n_alumnos)
//Precondici�n: El identificador pasado no puede ser nulo
//Postcondici�n: Menu que nos permite elegir las opciones para un alumno en especifico
void menu_alumnos_grupo_individual(char id[],char materia[], alumno *v_alumnos, int n_alumnos){
	int x,y,z,w;
	x=0;
	printf("Hola, estas en las opciones para un alumno. \n");
	do{
		while(y<1 || y>3){
			printf("Introduce el numero para elegir la opcion. \n");
			printf("1- Ficha del alumno. \n");
			printf("2- Calificaciones del alumno.\n");
			printf("3- Salir");
			scanf("%i",&y);
		}
		switch(y){
			case 1: do{
						if(comparar(id,v_alumnos[z].id_alum,6) == 0){
							printf("%s-%s-%s-%s-%s-%s.\n",v_alumnos[z].id_alum,v_alumnos[z].local_alum,v_alumnos[z].nombre_alum,v_alumnos[z].curso,v_alumnos[z].direc_alum,v_alumnos[z].grupo);
							printf("Si desea modificar algo pulse 1. \n");
							scanf("%i",&w);
							if(w==1){
								modif_alum(v_alumnos, n_alumnos, id);
								z=n_alumnos;
							}                  
						}
					}while(z<n_alumnos);break;
			case 2: Calificaciones_alumno(id,materia);break;
			case 3: x=1;break;
		}
	}while(x==0);
}

//Cabezera: void Calificaciones_alumno(char id[]char materia[])
//Precondici�n: Los valores de id y materia no pueden ser nulos
//Postcondici�n: Menu que nos permite elegir las opciones para las calificaciones de un alumno
void Calificaciones_alumno(char id[],char materia[]){
	int x,y;
	x=0;
	imprimir_nota(cali,id,materia);
	do{
		while(y<1 || y>4){
			printf("Introduce el numero para elegir la opcion. \n");
			printf("1- Modificar calificaciones. \n");
			printf("2- Anadir calificaciones. \n");
			printf("3- Eliminar calificaciones. \n");
			printf("4- Salir. \n");
		}
		switch(y){
			case 1: modificar_nota(&cali,id,materia);break;
			case 2: anadir_nota(&cali,id,materia,&num_lin_Matriculas.lon);break;
			case 3: eliminar_nota(&cali,id,materia,&num_lin_Matriculas.lon);break;
			case 4: x=1;break;
		}
	}while(x==0);
}

//Cabezera: void menu_administrador()
//Precondici�n: Tener los datos necesarios almacenados en las estructuras y tener un id de administrador
//Postcondici�n: Te deja elegir las funciones que puede realizar un usuario administrador
void menu_administrador(){
    int x,y;
    x=0;
    printf("Hola, estas dentro del perfil del administrador.\n");
    do{
        while(y<1 || y>5){
            printf("Introduce el numero de la opcion para entrar en dicha opcion.\n");
            printf("1- Usuarios.\n");
            printf("2- Alumnos.\n");
            printf("3- Materias.\n");
            printf("4- Horarios.\n");
            printf("5- Salir.\n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: menu_usuarios();break;
            case 2: menu_alumnos();break;
            case 3: menu_materias();break;
            case 4: menu_horarios();break;
            case 5: x=1;break;
        }
    }while(x==0);
}

//Cabezera: void menu_usuaruios()
//Precondici�n: Ninguna
//Postcondici�n: Entras en el menu de usuario para gestionar los datos de los usuarios
void menu_usuarios(){
    int x,y;
    x=0;
    printf("Hola, estas dentro del menu de gestion de usuarios.\n");
    do{
        while(y<1 || y>5){
            printf("Introduce el numero de la opcion para entrar en dicha opcion.\n");
            printf("1- Dar de alta a un usuario.\n");
            printf("2- Dar de baja a un usuario.\n");
            printf("3- Modificar lista de usuarios.\n");
            printf("4- Listar usuarios.\n");
            printf("5- Salir.\n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: altaUsuario(&vUsuarios,&nUsuarios);break;
            case 2: bajaUsuario(&vUsuarios,&nUsuarios);break;
            case 3: modificarUsuario(&vUsuarios,nUsuarios);break;
            case 4: listarUsuarios(vUsuarios,nUsuarios);break;
            case 5: x=1;break;
        }
    }while(x==0);
}

//Cabezera: void menu_alumnos()
//Precondici�n: Ninguna
//Postcondici�n: Entras en el menu de alumnos para gestionar los datos de los alumnos
void menu_alumnos(){
    int x,y;
    char id[7];
    x=0;
    printf("Hola, estas dentro del menu de gestion de usuarios.\n");
    do{
        while(y<1 || y>6){
            printf("Introduce el numero de la opcion para entrar en dicha opcion.\n");
            printf("1- Dar de alta a un alumno.\n");
            printf("2- Dar de baja a un alumno.\n");
            printf("3- Modificar lista de alumnos.\n");
            printf("4- Listar alumnos.\n");
            printf("5- Seleccionar alumno");
            printf("6- Salir.\n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: dar_alta_alum(v_alumnos,&n_alumnos);break;
            case 2: printf("Introduzca el id.\n");
            		fgets(id,7,stdin);
					dar_baja_alum(v_alumnos,n_alumnos,id);break;
            case 3: printf("Introduzca el id.\n");
            		fgets(id,7,stdin);
					modif_alum(v_alumnos,n_alumnos,id);break;
            case 4: listar_alum(v_alumnos,n_alumnos);break;
            case 5: menu_alumno_individual(v_alumnos,n_alumnos);break;
            case 6: x=1;break;
        }
    }while(x==0);
}

//Cabezera: void menu_alumno_individual(alumno *v_alumnos,int n_alumnos)
//Precondici�n: Ninguna
//Postcondici�n: Entras dentro de un menu donde te dan opciones para gestionar los datos de un alumno
void menu_alumno_individual(alumno *v_alumnos,int n_alumnos){
    int x,y,z,w;
    char nom_alum[21];
    char m1[5], m2[5];
    x=0;
    z=0;
    do{
        printf("Introduce el nombre de un alumno:");
        fgets(nom_alum,21,stdin);
    }while(z==0);
    do{
            printf("Seleccione una de las siguientes opciones: \n");
        while(y<1 || y>6){
            printf("1- Lista de materias. \n");
            printf("2- Cambio de matricula. \n");
            printf("3- Eliminar matricula. \n");
            printf("4- Matricular de una asignatura");
            printf("5- Salir");
            scanf("%i",&y);
        }
         switch(y){
            case 1: do{
            			if(comparar(nom_alum,v_alumnos[w].nombre_alum,20) == 0){
            				materias_alum(matri,v_alumnos[w].id_alum);
            				w=n_alumnos;
						}
						w++;
					}while(w<n_alumnos);break;
            case 2: printf("Introduce la antigua matricula. \n");
					fgets(m1,5,stdin);
					printf("Introduce la nueva matriculas. \n");
					fgets(m2,5,stdin);
					modificar_matricula(&matri,nom_alum,m1,m2);break;
            case 3: printf("Introduce la matricula que quieres borrar");
					fgets(m1,5,stdin);
					borrar_matricula(&matri,nom_alum,m1,&num_lin_Matriculas.lon);break;
            case 4: printf("Introduce la matricula que desea matricular al alumno");
					fgets(m1,5,stdin);
					anadir_matricula(&matri,nom_alum,m1,&num_lin_Matriculas.lon);break;
            case 5: x=1;break;
        }
    }while(x==0);
}

//Cabezera: void menu_materias()
//Precondici�n: Ninguna
//Postcondici�n: Entras en el menu de materias para gestionar los datos de las materias
void menu_materias(){
    int x,y;
    char m1[5];
    x=0;
    printf("Hola, estas dentro del menu de gestion de materias.\n");
    do{
        while(y<1 || y>5){
            printf("Introduce el numero de la opcion para entrar en dicha opcion.\n");
            printf("1- Dar de alta a una materia.\n");
            printf("2- Dar de baja a una materia.\n");
            printf("3- Modificar lista de materias.\n");
            printf("4- Eliminar una materia.\n");
            printf("5- Salir.\n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: dar_alta_mat(v_materias,&n_materias);break;
            case 2: printf("Introduce el id de la materia que quieras borrar. \n");
            		fgets(m1,5,stdin);
					dar_baja_mat(v_materias,n_materias,m1);break;
            case 3: printf("Introduce el id de la materia que quieras modificar. \n");
            		fgets(m1,5,stdin);
					modif_mat(v_materias,n_materias,m1);break;
            case 4: listar_mat(v_materias,n_materias);break;
            case 5: x=1;break;
        }
    }while(x==0);
}

//Cabezera : void menu_horarios()
//Precondici�n: Ninguna
//Postcondici�n: Entras en el menu de horarios para gestionar los datos de los horarios
void menu_horarios(){
    int x,y;
    x=0;
    printf("Hola, estas dentro del menu de gestion de horarios.\n");
    do{
        while(y<1 || y>5){
            printf("Introduce el numero de la opcion para entrar en dicha opcion.\n");
            printf("1- Anadir horas de clase.\n");
            printf("2- Eliminar horas de clase.\n");
            printf("3- Modificar horarios de clase.\n");
            printf("4- Listar horarios.\n");
            printf("5- Salir.\n");
            scanf("%i",&y);
        }
        switch(y){
            case 1: annadirHoras(&vHorarios,&nHorarios);break;
            case 2: eliminarHoras(&vHorarios,&nHorarios);break;
            case 3: modificarHoras(&vHorarios,nHorarios);break;
            case 4: listarHorarios(vHorarios,nHorarios);break;
            case 5: x=1;break;
        }
    }while(x==0);
}

