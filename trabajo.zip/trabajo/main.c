#include "menus.h"
#include <stdio.h>

int main(){
    inicio_cuaderno();
    return 0;
}
