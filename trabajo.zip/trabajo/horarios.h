//Declaraciones m�dulo Horarios.

#ifndef _HORARIOS_H_
#define _HORARIOS_H_

typedef struct {
	char id_prof[4];		//Identificador del profesor (Id_profesor), tres d�gitos (debe coincidir con un identificador deusuario, Id_usuario, con perfil profesor del fichero Usuarios.txt).
	int dia_clase;			//D�a (D�a_clase), valor num�rico de 1 a 5 que indica el d�a de la semana que imparte clase de la materia el profesor.
	int hora_clase;			//Hora (Hora_clase), valor num�rico de 1 a 6 que indica el tramo horario en el que imparte clase de la materia el profesor.
	char id_materia[5];		//Identificador de la materia (Id_materia), 4 d�gitos (debe coincidir con el Id_materia de alguna materia del fichero Materias.txt)
	char grupo[11];			//Grupo (Grupo) al que imparte clase, 10 caracteres m�ximo (debe coincidir con alg�n grupo de los que aparecen en el fichero Alumnos.txt).
	
}tipo_Horario;

tipo_Horario *vHorarios;
int nHorarios;


void cargarHorarios(tipo_Horario **, int *);


void volcarHorarios(tipo_Horario *vHorarios, size_t tam);


void listarHorarios (tipo_Horario *, int);


void annadirHoras(tipo_Horario **, int *);


void eliminarHoras(tipo_Horario **,int *);


void modificarHoras(tipo_Horario **, int);


void cambiolinea (char *);

#endif	//_HORARIOS_H_

